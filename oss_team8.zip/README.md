Stress Calendar v.1.0.0
=========
## Motive and Goal
* The goal is to break away from the ordinary To-Do calendar and easily grasp the intensity of assignment and the priority order of assignment by giving the assignments given to them the degree of stress.

## Features
1. basic functions of calendar
2. Like a planner, provide assignment handling function by date.
3. Visually express the level of stress in each assignment.
4. Additionally, it provides a function to measure study time.
## Example
* The basic screen.
![image](https://github.com/keyhundred/TodoMate/blob/main/img/Screenshot_day.png)
* The basic screen (from 18 to 6).
![image](https://github.com/keyhundred/TodoMate/blob/main/img/Screenshot_night.png)
* Set Todo & Stress.
![image](https://github.com/keyhundred/TodoMate/blob/main/img/Screenshot_stress.png)
* Use timer.
![image](https://github.com/keyhundred/TodoMate/blob/main/img/Screenshot_timer.png)

## Demo Video  
Please see our demo video at https://youtu.be/YWGaSu9kebY
### Member
* 2017314106 한재웅 hxxjaewoong17@gmail.com
* 2018312179 박정인  dls0901@naver.com
* 2020315008 이상엽 skkulsy0117@naver.com
### History

- Nov 22, 2021 Calendar Completed
- Nov 23, 2021 Stress functions added
